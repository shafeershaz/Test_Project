

exports.test = function(req, res, next) {
    console.log("got Test ")
}